from __future__ import annotations

import subprocess
import sys
import unittest
from unittest import mock
from pathlib import Path

from scripts import kesher_content_controller_v4 as v4
from scripts import kesher_content_controller_stabilized as stabilized
from scripts.kesher_runtime.identity import MediaIdentity
from scripts.kesher_runtime.outbox import workflow_for
from scripts.kesher_runtime.state import StateInvalid
from tests.test_kesher_canonical_state import SOURCE, requested

ROOT = Path(__file__).resolve().parents[1]
CONTROLLER_WORKFLOW = ROOT / ".github" / "workflows" / "kesher-content-controller.yml"
SHORT_WORKFLOW = ROOT / ".github" / "workflows" / "kesher-short-v4.yml"
SHORT_COMPONENT = ROOT / "src" / "remotion" / "ArticleShort.tsx"
SHORT_TYPES = ROOT / "src" / "remotion" / "ArticleShort.types.ts"
SHORT_ROOT = ROOT / "src" / "remotion" / "Root.tsx"
V4_RUNTIME = ROOT / "scripts" / "kesher_content_controller_v4_runtime.py"
STABILIZED_RUNTIME = ROOT / "scripts" / "kesher_content_controller_stabilized.py"


class V4RuntimeActivationTests(unittest.TestCase):
    def test_content_controller_owns_both_canonical_media_products_and_retires_v5_entry(self):
        workflow = CONTROLLER_WORKFLOW.read_text(encoding="utf-8")
        self.assertIn("python -m scripts.kesher_runtime.controller_entry --mode live", workflow)
        self.assertNotIn("scripts/kesher_content_controller_stabilized.py", workflow)
        for kind in ("overview", "short"):
            with self.subTest(kind=kind):
                state, command_id = requested(target=MediaIdentity(SOURCE, kind))
                command = state["commands"][command_id]
                self.assertEqual(command["target"]["kind"], kind)
                self.assertEqual(workflow_for(command), "kesher-media-worker.yml")
        legacy_source = STABILIZED_RUNTIME.read_text(encoding="utf-8")
        self.assertIn("kesher_content_controller_v5_runtime", legacy_source)
        self.assertIn("runtime.install_runtime()", legacy_source)
        with mock.patch.object(stabilized, "install_runtime") as install:
            with self.assertRaisesRegex(StateInvalid, "LEGACY_ENTRYPOINT_RETIRED"):
                stabilized.main()
        install.assert_not_called()

    def test_v4_runtime_dispatches_only_the_dedicated_short_workflow(self):
        source = V4_RUNTIME.read_text(encoding="utf-8")
        self.assertIn('SHORT_WORKFLOW_FILE = "kesher-short-v4.yml"', source)
        self.assertIn('SHORT_WORKFLOW_NAME = "Kesher Daily Article Short V4"', source)
        self.assertIn('SHORT_STATE_ARTIFACT = "kesher-short-v4-state"', source)
        self.assertIn("v4.core.VIDEO_WORKFLOW = SHORT_WORKFLOW_FILE", source)
        self.assertIn("v4.core.VIDEO_STATE_ARTIFACT = SHORT_STATE_ARTIFACT", source)
        self.assertIn("v4.v3.entry.VIDEO_WORKFLOW_NAME = SHORT_WORKFLOW_NAME", source)

    def test_v4_runtime_reuses_existing_protected_article_merge_worker(self):
        source = V4_RUNTIME.read_text(encoding="utf-8")
        self.assertIn('ARTICLE_AUTO_MERGE_WORKFLOW = "auto-merge-article-prs.yml"', source)
        self.assertIn("v4.AUTO_MERGE_WORKFLOW = ARTICLE_AUTO_MERGE_WORKFLOW", source)
        self.assertNotIn('ARTICLE_AUTO_MERGE_WORKFLOW = "auto-merge-article-prs-v4.yml"', source)

    def test_v4_runtime_archives_same_day_legacy_video_state_instead_of_adopting_it(self):
        source = V4_RUNTIME.read_text(encoding="utf-8")
        self.assertIn('state.setdefault("migration", {})["legacy_video_v3"]', source)
        self.assertIn('"attempts": 0', source)
        self.assertIn('"resume_dispatches": 0', source)
        self.assertIn('"fifth_attempt_recovery_only_used": False', source)
        self.assertIn('state["status"] = "article_live"', source)

    def test_direct_script_import_mode_matches_github_actions(self):
        code = (
            "import os,sys; "
            "root=os.getcwd(); scripts=os.path.join(root,'scripts'); "
            "sys.path=[scripts]+[p for p in sys.path if p not in ('',root)]; "
            "import kesher_content_controller_v4_runtime"
        )
        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_stale_rebuild_is_not_dispatched_after_latest_state_advanced(self):
        class FakeGitHub:
            def newest_video_state(self):
                return {
                    "version": 1,
                    "items": [{
                        "id": "video-current",
                        "status": "uploaded",
                        "uploaded": True,
                        "youtube_id": "public-current",
                        "source": {"slug": "today-article"},
                    }],
                }

        controller = object.__new__(v4.V4Controller)
        controller.github = FakeGitHub()
        state = {
            "article": {"slug": "today-article"},
            "video": {"attempt_count": 0, "resume_dispatches": 0},
        }
        stale = {"operation": "rebuild", "rebuild_item_id": "video-stale"}
        with mock.patch.object(v4.core.GitHubClient, "dispatch") as dispatch:
            controller._dispatch_budgeted(state, "video", "kesher-short-v4.yml", stale)
        dispatch.assert_not_called()

    def test_short_workflow_is_the_single_controller_owned_v4_worker(self):
        workflow = SHORT_WORKFLOW.read_text(encoding="utf-8")
        self.assertIn("name: Kesher Daily Article Short V4", workflow)
        self.assertIn("scripts/kesher_short_pipeline_v4.py", workflow)
        self.assertIn("- release", workflow)
        self.assertIn("- derive", workflow)
        self.assertIn("release_slug:", workflow)
        self.assertIn("derive_content_sha256:", workflow)
        self.assertIn("--release-without-short", workflow)
        self.assertIn("NATIVE_SHORT_RECOVERY_SOURCE_VERIFIED", workflow)
        self.assertIn('id: rebuild_exact', workflow)
        self.assertIn('--prepare-upload --slug "$REBUILD_SLUG" --content-sha256 "$REBUILD_CONTENT_SHA256" --item-id "$REBUILD_ITEM_ID"', workflow)
        self.assertIn('--upload-only --item-id "$REBUILD_ITEM_ID"', workflow)
        self.assertNotIn("--adopt-long-form-state", workflow)
        self.assertNotIn("Generate or resume exact Video Overview", workflow)

    def test_article_short_embeds_the_notebooklm_video_and_audio(self):
        component = SHORT_COMPONENT.read_text(encoding="utf-8")
        types = SHORT_TYPES.read_text(encoding="utf-8")
        self.assertIn('from "@remotion/media"', component)
        self.assertIn("Video", component)
        self.assertIn("videoSrc: string", types)
        self.assertIn("sourceStartFrame: number", types)
        self.assertIn("durationInFrames: number", types)
        self.assertIn("<Video", component)
        self.assertIn("staticFile(videoSrc)", component)
        self.assertIn("trimBefore={sourceStartFrame}", component)
        self.assertIn("durationInFrames={durationInFrames}", component)

    def test_short_composition_preserves_source_duration_for_signature_overlay(self):
        root = SHORT_ROOT.read_text(encoding="utf-8")
        self.assertNotIn("SHORT_SIGNATURE_OUTRO_FRAMES", root)
        self.assertIn("durationInFrames: props.durationInFrames", root)
        self.assertIn('videoSrc: "kesher-input.mp4"', root)
        self.assertIn("sourceStartFrame: 0", root)


if __name__ == "__main__":
    unittest.main()
