const assert = require('assert');
const { execFileSync } = require('child_process');
const fs = require('fs');

function read(path) {
  return fs.readFileSync(path, 'utf8');
}

function testControllerHardening() {
  const articlePolicy = read('.github/prompts/jules-weekday-article-update.md');
  for (const path of [
    '.github/workflows/jules-daily-seo-geo-review.yml',
    '.github/workflows/jules-daily-mobile-review.yml',
    '.github/workflows/jules-nightly-site-fixes.yml',
    '.github/workflows/jules-daily-industry-benchmarking.yml',
    '.github/workflows/jules-weekly-content-review.yml',
  ]) {
    const workflow = read(path);
    assert(workflow.includes('strictly defined as a couples counselor'), `${path} must define the professional role`);
    assert(workflow.includes('family mediation (גישור)'), `${path} must retain the mediation exclusion`);
  }
  assert(!articlePolicy.includes('מגשרת מוסמכת'));
  assert(!articlePolicy.includes('עורכת דין בהכשרתה'));
  assert(articlePolicy.includes('אין להוסיף, לשנות או להתייחס לגירושין, שירותים משפטיים'));
}

function testContentValidatorContracts() {
  const validator = read('scripts/validate-content.cjs');
  assert(validator.includes('Post summaries are stale or incomplete; run npm run generate after the final posts.json edit.'));
  assert(validator.includes('const visibleProse = `${post.title}\\n${post.excerpt}\\n${stripHtml(post.content)}`'));
  assert(validator.includes('if (i === 0)'));
  for (const phrase of [
    'זה קורה כמעט לכל מי', 'טבעית לחלוטין', 'הצעד הראשון להתמודדות',
    'המלכודת הגדולה ביותר', 'הקצב שלכם הוא הקצב שלכם', 'אין לוח זמנים אוניברסלי',
    'מלאים ושלמים יותר', 'זירת התגוששות', 'שדה מוקשים', 'לנווט את התקופה',
    'הבנה עמוקה', 'חיבור אמיתי',
  ]) {
    assert(validator.includes(`"${phrase}"`), `Missing observed phrase guard: ${phrase}`);
  }
}

function testTrustedArticleImageV2() {
  const workflow = read('.github/workflows/kesher-article-image.yml');
  const trigger = workflow.split('permissions:', 1)[0];
  const workerV3 = read('.github/scripts/article-image-worker-v3.py');
  const workerV4 = read('.github/scripts/article-image-worker-v4.py');
  const generation = read('.github/workflows/kesher-article-generation.yml');
  const runnerV3 = read('scripts/jules_article_runner_v3.py');
  const runnerV4 = read('scripts/jules_article_runner_v4.py');
  const controllerWorkflow = read('.github/workflows/kesher-content-controller.yml');
  const stabilizedController = read('scripts/kesher_content_controller_stabilized.py');
  const contract = JSON.parse(read('config/kesher-production-contract.json'));

  assert.strictEqual(contract.controller_state_schema_version, 3);
  assert.strictEqual(contract.retry.max_attempts_per_stage, 3);
  assert.deepStrictEqual(contract.retry.backoff_minutes, [5, 15]);
  assert.strictEqual(contract.image.required_for_article, true);
  assert.strictEqual(contract.image.publication_blocking, true);
  assert.strictEqual(contract.image.no_image_publication_allowed, false);
  assert.strictEqual(contract.image.failure_mode, 'blocking-retry');
  assert.strictEqual(contract.image.worker_attempts_per_dispatch, 1);
  assert.strictEqual(contract.image.max_attempts, 3);
  assert.deepStrictEqual(contract.image.provider_order, ['gemini', 'pexels', 'pixabay', 'local-curated']);
  assert.strictEqual(contract.image.abstract_placeholder_allowed, false);
  assert.strictEqual(contract.image.owned_generation_variants, 3);
  assert.strictEqual(contract.image.local_fallback_candidates_per_category, 40);
  assert.strictEqual(contract.image.managed_fallback_library_target_per_category, 40);
  assert.strictEqual(contract.image.local_fallback_reuse_cooldown_days, 90);
  assert.strictEqual(contract.image.local_fallback_max_lifetime_uses, 3);
  assert.strictEqual(contract.image.gemini_model, 'gemini-3.1-flash-image');
  assert.strictEqual(contract.image.visual_verifier_model, 'gemini-3.5-flash');
  assert.strictEqual(contract.image.external_stock_requires_pixel_verification, true);

  assert(!trigger.includes('pull_request_target:'));
  assert(trigger.includes('workflow_dispatch:'));
  assert(workflow.includes('run-name: Kesher Image PR'));
  assert(workflow.includes('Checkout trusted image worker'));
  assert(workflow.includes('ref: main'));
  assert(workflow.includes('persist-credentials: false'));
  assert(workflow.includes('GOOGLE_API_KEY'));
  assert(!workflow.includes('UNSPLASH_ACCESS_KEY'));
  assert(workflow.includes('PEXELS_API_KEY'));
  assert(workflow.includes('PIXABAY_API_KEY'));
  assert(workflow.includes('article-image-worker-v4.py'));
  assert(workflow.includes('actions/workflows/ci.yml/dispatches'));
  assert(controllerWorkflow.includes('Kesher Trusted Article Image'));
  assert(controllerWorkflow.includes('kesher_content_controller_stabilized.py'));
  assert(stabilizedController.includes('kesher_content_controller_v5_runtime'));
  assert(stabilizedController.includes('runtime.install_runtime()'));
  assert(!controllerWorkflow.includes('kesher_content_controller_v3_best_effort.py --report-json'));

  assert(workerV3.includes('GEMINI_MODEL = "gemini-3.1-flash-image"'));
  assert(workerV3.includes('VERIFY_MODEL = "gemini-3.5-flash"'));
  assert(workerV4.includes('for provider in (try_gemini_variants, try_pexels, try_pixabay)'));
  assert(workerV3.includes('/v1/models/{GEMINI_MODEL}:generateContent'));
  assert(workerV3.includes('verify_pixels(post, data, ext)'));
  assert(workerV3.includes('ARTICLE_IMAGE_COMMITTED'));

  assert(workerV4.includes('candidate_path.read_bytes()'));
  assert(workerV4.includes('IMAGE_PROVIDER_PREFLIGHT'));
  assert(workerV4.includes('"local": True'));
  assert(workerV4.includes('collect_existing_image_usage'));
  assert(workerV4.includes('sha256_collision'));
  assert(workerV4.includes('load_seed_manifest'));
  assert(workerV4.includes('load_bank_manifest'));
  assert(workerV4.includes('reuse_cooldown_days'));
  assert(workerV4.includes('max_lifetime_uses'));
  assert(!workerV4.includes('LocalEditorial'));
  assert(!workerV4.includes('generate_editorial_fallback'));
  assert(workerV3.includes('stock_queries'));
  assert(!workerV4.includes('core.github_content(repo, source_path'));

  assert(generation.includes('scripts/jules_article_runner_v4.py'));
  assert(runnerV4.includes('jules_article_runner_v3'));
  assert(runnerV4.includes('v3.main()'));
  assert(runnerV3.includes('Jules owns ARTICLE TEXT ONLY'));
  assert(runnerV3.includes('The new article MUST omit'));
  assert(runnerV3.includes('trusted GitHub Actions stage'));
  assert(runnerV3.includes('verified Pexels -> verified Pixabay'));
  assert(!runnerV3.includes('Gemini -> Unsplash -> Pexels'));
  assert(!articleController.includes('Article publication is allowed without an image'));
  assert(!articleController.includes('if image_status == "deferred"'));
}

function testIndependentArticlePrGateRuntime() {
  execFileSync('python3', ['-c', `
import runpy, io, hashlib, json
from PIL import Image
controller = runpy.run_path('.github/scripts/article-pr-controller-v3.py')
validator = controller['load_validator_best_effort']()
evaluate = validator.evaluate
head_sha = 'a' * 40
base = [{'id':'older'}]
content = '<p>' + ('מילה ' * 700) + '</p>' + ('<h3>שאלה</h3>' * 5)
base_pr = {
  'state':'open','draft':False,'title':'Publish Kesher article: valid-new-post',
  'base':{'sha':'c' * 40,'ref':'main','repo':{'full_name':'test/repo'}},
  'head':{'sha':head_sha,'repo':{'full_name':'test/repo'}},
}
checks = [{'name':'verify','conclusion':'success','head_sha':head_sha}]

no_image = {'id':'valid-new-post','content':content}
errors = evaluate(base_pr, [{'filename':'src/data/posts.json'}], checks, base, base+[no_image], lambda _: b'')
assert any('no-image publication is forbidden' in e for e in errors), errors

output = io.BytesIO()
Image.new('RGB', (1200,675), (96,127,150)).save(output, format='PNG')
png = output.getvalue()
sha = hashlib.sha256(png).hexdigest()
post = dict(no_image, image='/images/generated/blog/valid-new-post.png', imageAlt='זוג בשיחה פנים אל פנים המדגישה הקשבה ותקשורת באופן ברור')
post_sha = hashlib.sha256(json.dumps(post, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
body = f'''Image Pipeline Version: 2
Image Provider: Local
Image Attempt Chain: gemini-1/pexels/pixabay/local-curated
Image Generation Result: local_fallback
Image Source URL: local://public/images/generated/blog/listening-in-relationships.jpg
Image SHA-256: {sha}
Image Dimensions: 1200x675
Image Visual Match: זוג בשיחה פנים אל פנים המדגישה הקשבה ותקשורת באופן ברור
Image Article ID: valid-new-post
Image Article SHA-256: {post_sha}
Image Evidence Head: {head_sha}'''
pr = dict(base_pr, body=body)
files = [{'filename':'src/data/posts.json'}, {'filename':'public/images/generated/blog/valid-new-post.png'}]
errors = evaluate(pr, files, checks, base, base+[post], lambda _: png)
assert errors == [], errors

for old, new, expected in [
  ('Image SHA-256: ' + sha, 'Image SHA-256: ' + '0'*64, 'SHA-256 mismatch'),
  ('Image Pipeline Version: 2', 'Image Pipeline Version: 1', 'Pipeline Version'),
  ('Image Generation Result: local_fallback', 'Image Generation Result: stock', 'local_fallback'),
  ('Image Provider: Local', 'Image Provider: Unknown', 'trusted Image Provider'),
  ('Image Dimensions: 1200x675', 'Image Dimensions: 640x360', 'dimensions mismatch'),
  ('Image Article SHA-256: ' + post_sha, 'Image Article SHA-256: ' + '0'*64, 'current article content'),
  ('Image Evidence Head: ' + head_sha, 'Image Evidence Head: ' + 'b'*40, 'current PR head'),
  ('local://public/images/generated/blog/listening-in-relationships.jpg', 'local://../untrusted.jpg', 'repository source'),
]:
  errors = evaluate(dict(pr, body=body.replace(old, new)), files, checks, base, base+[post], lambda _: png)
  assert any(expected in e for e in errors), (expected, errors)

for changed in [dict(post, title='changed'), dict(post, imageAlt='תיאור חלופי שאינו תואם להוכחת המאמר')]:
  errors = evaluate(pr, files, checks, base, base+[changed], lambda _: png)
  assert any('current article content' in e for e in errors), errors
errors = evaluate(pr, files, [dict(checks[0], head_sha='b'*40)], base, base+[post], lambda _: png)
assert any('current head' in e for e in errors), errors

corrupt = png[:24]
corrupt_body = body.replace(sha, hashlib.sha256(corrupt).hexdigest())
errors = evaluate(dict(pr, body=corrupt_body), files, checks, base, base+[post], lambda _: corrupt)
assert any('Image validation failed' in e for e in errors), errors

video = dict(post, video='/videos/generated/placeholder.mp4')
errors = evaluate(pr, files+[{'filename':'public/videos/generated/placeholder.mp4'}], checks, base, base+[video], lambda _: png)
assert any('video' in e.lower() for e in errors), errors
`]);
}

function testArticleAutomergeAndRepairContracts() {
  const workflow = read('.github/workflows/auto-merge-article-prs.yml');
  const controller = read('.github/scripts/article-pr-controller.py');
  const controllerV3 = read('.github/scripts/article-pr-controller-v3.py');
  const gate = read('.github/scripts/validate-article-pr.py');
  assert(workflow.includes('Checkout trusted article controller'));
  assert(workflow.includes('ref: main'));
  assert(workflow.includes('python3 .github/scripts/article-pr-controller-v3.py'));
  assert(/permissions:[\s\S]*actions:\s*write/.test(workflow));
  assert(controller.includes('load_validator()'));
  assert(controller.includes('validator.evaluate('));
  assert(controllerV3.includes('LEGACY_PATH = Path(__file__).with_name("article-pr-controller.py")'));
  assert(controllerV3.includes('MAX_TOTAL_CONTENT_ATTEMPTS = 3'));
  assert(controllerV3.includes('Repair THE SAME PR #'));
  assert(controllerV3.includes('A missing image is not a content failure'));
  assert(controller.indexOf('merged = request_json(') < controller.indexOf('/actions/workflows/deploy.yml/dispatches'));
  assert(gate.includes('Expected exactly one new article'));
  assert(gate.includes('Article publication PR may not modify or remove existing posts'));
  assert(gate.includes('New article word count must be 700-1100'));
}

function testJulesWatchdogContracts() {
  const watchdog = read('.github/scripts/watch-jules-session.py');
  for (const contract of [
    'AWAITING_USER_FEEDBACK', 'WAITING_FOR_USER', ':sendMessage', 'max_replacements',
    'AUTONOMOUS RECOVERY REQUIREMENT', 'COMPLETED with changeSet but no pullRequest',
    'AUTONOMOUS_CLEANUP_GRACE_SECONDS', 'REPEATED_WAITING_CONTINUATION',
    'max_waiting_continuations', 'Use Jules built-in PR submission', '"PAUSED"',
    'DELIVERY RECOVERY REQUIREMENT:', 'max_delivery_replacements', 'Previous changeSet candidate paths:',
  ]) {
    assert(watchdog.includes(contract), `Jules watchdog missing ${contract}`);
  }
  assert.strictEqual(watchdog.split('deadline = time.monotonic() + max_seconds').length - 1, 5);
}

function testOtherAuditAutonomyContracts() {
  const audit = read('.github/workflows/auto-merge-jules-audit-prs.yml');
  const seo = read('.github/workflows/jules-daily-seo-geo-review.yml');
  const mobile = read('.github/workflows/jules-daily-mobile-review.yml');
  const site = read('.github/workflows/jules-nightly-site-fixes.yml');
  const industry = read('.github/workflows/jules-daily-industry-benchmarking.yml');
  assert(audit.includes('Closed zero-file stale/duplicate audit PR.'));
  assert(audit.includes('Failing explicitly instead of reporting false success.'));
  assert(audit.includes('cron: "17,47 * * * *"'));
  assert(audit.includes('mobile_route_evidence_valid'));
  assert(seo.includes('Final live-duplicate gate:'));
  assert(seo.includes('Discovery-to-action invariant:'));
  assert(mobile.includes('Asking whether to fix that issue or inspect another page is forbidden.'));
  assert(site.includes('Public-route evidence rule:'));
  assert(industry.includes('Evidence-before-edit gate:'));
  for (const workflow of [seo, mobile, site, industry]) {
    assert(workflow.includes('Enforce autonomous terminal Jules state'));
    assert(workflow.includes('.github/scripts/watch-jules-session.py'));
  }
}

function testTechnicalVideoPublicationCannotBeRegressed() {
  const daily = read('.github/workflows/kesher-daily-video.yml');
  const contract = JSON.parse(read('config/kesher-production-contract.json'));
  assert.strictEqual(contract.video.publication_gate, 'technical');
  assert.strictEqual(contract.video.jules_review, 'advisory');
  assert.strictEqual(contract.video.durable_state_artifacts_to_keep, 3);
  assert.strictEqual(contract.video.max_attempts_per_stage, 3);
  assert(daily.includes('Jules performs strict advisory review'));
  assert(daily.includes('Prepare technically verified upload'));
  assert(daily.includes('Upload exact technically verified MP4'));
  assert(daily.includes('continue-on-error: true'));
  assert(!daily.includes('mandatory Jules'));
  assert(!daily.includes('Jules-approved MP4'));
  assert(!daily.includes('Upload only after all mandatory review gates approve'));
  assert(daily.includes('Keep the newest three durable state artifacts'));
  assert(daily.includes('| .[3:] | .[].id'));
}

testControllerHardening();
testContentValidatorContracts();
testTrustedArticleImageV2();
testIndependentArticlePrGateRuntime();
testArticleAutomergeAndRepairContracts();
testJulesWatchdogContracts();
testOtherAuditAutonomyContracts();
testTechnicalVideoPublicationCannotBeRegressed();
console.log('All automation gates tests passed.');
