import React, { useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { FaWhatsapp } from 'react-icons/fa';
import { FiCalendar } from 'react-icons/fi';
import DOMPurify from 'dompurify';
import posts from '../../data/publishedPosts';
import articleVideos from '../../data/articleVideos.json';
import ArticleVideoCard from '../../components/ArticleVideoCard/ArticleVideoCard';
import MetaTags from '../../components/SEO/MetaTags';
import SchemaOrg from '../../components/SEO/SchemaOrg';
import LeadMagnet from '../../components/LeadMagnet/LeadMagnet';
import ShareButtons from '../../components/ShareButtons/ShareButtons';
import GooglePreferredSource from '../../components/GooglePreferredSource/GooglePreferredSource';
import SignatureMark from '../../components/Signature/SignatureMark';
import { SITE_CONFIG } from '../../constants/siteConfig';
import { getImageDimensions } from '../../data/imageDimensions';
import NotFound from '../NotFound/NotFound';
import styles from './BlogPost.module.css';

const articleCtaCopy = (post: (typeof posts)[number]) => {
  const subcategory = 'subcategory' in post && typeof post.subcategory === 'string' ? post.subcategory : '';
  const context = `${post.category} ${subcategory} ${post.title}`;

  if (/רילוקיישן|עלייה|הגירה/.test(context)) {
    return 'אם המעבר, החזרה לארץ או השינוי הגדול משפיעים גם על הקשר או על האווירה בבית, אפשר לפנות לשירה לייעוץ פרטני. יחד אפשר לעשות סדר במה שקורה ולבחון צעדים שמתאימים לכם.';
  }

  if (/הור|ילד|כיתה|קשב|מחונ/.test(context)) {
    return 'אם הנושא במאמר דומה למה שקורה אצלכם בבית, אפשר לפנות לשירה לייעוץ פרטני. יחד אפשר להבין מה עומד מאחורי הקושי ולבחור צעדים שמתאימים לילד ולמשפחה.';
  }

  if (/רווק|דייט|היכרות|מציאת זוגיות/.test(context)) {
    return 'אם השאלות במאמר פוגשות את מה שקורה אצלך עכשיו, אפשר לפנות לשירה לייעוץ פרטני וממוקד. יחד אפשר לברר את הדפוסים, הצרכים והצעדים הבאים שמתאימים לך.';
  }

  return 'אם מה שקראתם כאן דומה למה שקורה אצלכם בזוגיות, אפשר לפנות לשירה לייעוץ פרטני וממוקד. יחד אפשר לעשות סדר בקושי, בתקשורת ובצעדים הבאים שמתאימים לכם.';
};

const BlogPost: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const post = posts.find((candidate) => candidate.id === id);
  const canonicalRouteKey = post?.id || '';
  const articleVideo = post
    ? (articleVideos as Record<string, { youtubeId: string; title?: string }>)[post.id]
    : undefined;

  const schemaData = useMemo(() => ({
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Article",
        "@id": `${SITE_CONFIG.url}/blog/${canonicalRouteKey}#article`,
        "headline": post?.title || "",
        ...(post?.image ? { "image": `${SITE_CONFIG.url}${post.image}` } : {}),
        "url": `${SITE_CONFIG.url}/blog/${canonicalRouteKey}`,
        "datePublished": post?.date || "",
        "dateModified": (post && 'updatedAt' in post && typeof post.updatedAt === 'string' && post.updatedAt.trim())
          ? post.updatedAt.trim()
          : (post?.date || ""),
        "author": {
          "@type": "Person",
          "@id": `${SITE_CONFIG.url}/#shira`,
          "name": SITE_CONFIG.author,
          "url": `${SITE_CONFIG.url}/about`
        },
        "publisher": {
          "@type": "LocalBusiness",
          "@id": `${SITE_CONFIG.url}/#business`
        },
        "mainEntityOfPage": {
          "@type": "WebPage",
          "@id": `${SITE_CONFIG.url}/blog/${canonicalRouteKey}`
        },
        "inLanguage": "he",
        "description": post?.excerpt || "",
        "articleBody": post?.content?.replace(/<[^>]+>/g, ' ') || ""
      },
      {
        "@type": "BreadcrumbList",
      "@id": `${SITE_CONFIG.url}/blog/${canonicalRouteKey}#breadcrumb`,
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "עמוד הבית",
            "item": SITE_CONFIG.url
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "בלוג",
            "item": `${SITE_CONFIG.url}/blog`
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": post?.title || "",
            "item": `${SITE_CONFIG.url}/blog/${canonicalRouteKey}`
          }
        ]
      }
    ]
  }), [post, canonicalRouteKey]);

  if (!post) {
    return <NotFound />;
  }

  const safeContent = DOMPurify.sanitize(post.content);
  const shareUrl = `${SITE_CONFIG.url}/blog/${canonicalRouteKey}`;
  const directAnswer = 'directAnswer' in post && typeof post.directAnswer === 'string'
    ? post.directAnswer.trim()
    : '';
  const articleSummary = directAnswer || post.excerpt.trim();
  const relatedService = 'serviceUrl' in post
    && 'serviceLabel' in post
    && typeof post.serviceUrl === 'string'
    && typeof post.serviceLabel === 'string'
    ? { url: post.serviceUrl, label: post.serviceLabel }
    : null;
  const ctaCopy = articleCtaCopy(post);
  const displayCategory = post.category === 'הנחיית הורים' ? 'הדרכת הורים' : post.category;
  const imageMeta = post as typeof post & {
    imageProvider?: string;
    imageSourceUrl?: string;
    imageCredit?: string;
    imageCreditUrl?: string;
    imageIsFallback?: boolean;
  };

  return (
    <article className={styles.post}>
      <MetaTags
        title={post.title}
        description={post.excerpt}
        ogType="article"
        image={post.image}
        canonical={`${SITE_CONFIG.url}/blog/${canonicalRouteKey}`}
      />
      <SchemaOrg data={schemaData} />
      <header className={styles.header}>
        <div className="container">
          <Link to="/blog" className={styles.backLink}>← חזרה לבלוג</Link>
          <span className={styles.category}>{displayCategory}</span>
          <h1 className={styles.title}>{post.title}</h1>
          {articleSummary && (
            <div className={styles.directAnswer} role="region" aria-label="תשובה תמציתית">
              <div className={styles.directAnswerBadge}>תקציר מעשי</div>
              <p className={styles.directAnswerText}>{articleSummary}</p>
            </div>
          )}
          <div className={styles.authorByline}>
            <span>מאת: </span>
            <Link to="/about" className={styles.authorLink}>{post.author || SITE_CONFIG.author}</Link>
            <span className={styles.metaDivider}>•</span>
            <span className={styles.date} data-kesher-article-date={post.date}>{new Date(post.date).toLocaleDateString('he-IL')}</span>
            {'updatedAt' in post && typeof post.updatedAt === 'string' && post.updatedAt && post.updatedAt !== post.date && (
              <>
                <span className={styles.metaDivider}>•</span>
                <span className={styles.updatedDate}>עודכן: {new Date(post.updatedAt).toLocaleDateString('he-IL')}</span>
              </>
            )}
          </div>
          <ShareButtons
            title={post.title}
            url={shareUrl}
            itemId={post.id}
            placement="article_top"
          />
        </div>
      </header>
      <div className={`container ${styles.container}`}>
        <div className={styles.mainContent}>
          {post.image && (
            <>
              <div className={styles.imageWrapper}>
                <img
                  data-kesher-article-hero
                  src={post.image}
                  alt={post.imageAlt || post.title}
                  className={styles.image}
                  fetchPriority="high"
                  {...getImageDimensions(post.image)}
                />
              </div>
              {imageMeta.imageCredit && imageMeta.imageCreditUrl && (
                <p className={styles.imageCredit}>
                  <a href={imageMeta.imageCreditUrl} target="_blank" rel="noopener noreferrer">
                    {imageMeta.imageCredit}
                  </a>
                </p>
              )}
            </>
          )}
          <div className={styles.content} dangerouslySetInnerHTML={{ __html: safeContent }} />
          {'expertInsight' in post && typeof post.expertInsight === 'string' && post.expertInsight.trim() && (
            <aside className={styles.expertInsight} aria-label="תובנת מומחה מאת שירה סהרוני">
              <div className={styles.expertInsightHeader}>תובנת מומחה — שירה סהרוני</div>
              <p className={styles.expertInsightText}>{post.expertInsight.trim()}</p>
            </aside>
          )}
          {'evidence' in post && Array.isArray(post.evidence) && post.evidence.length > 0 && (
            <section className={styles.evidenceSection} aria-label="מקורות ואסמכתאות מקצועיות">
              <h3 className={styles.evidenceHeading}>מקורות ואסמכתאות מקצועיות</h3>
              <ul className={styles.evidenceList}>
                {(post.evidence as Array<{ title: string; url?: string; source?: string; note?: string }>).map((item, idx) => (
                  <li key={idx} className={styles.evidenceItem}>
                    {item.url ? (
                      <a href={item.url} target="_blank" rel="noopener noreferrer" className={styles.evidenceLink}>
                        {item.title}
                      </a>
                    ) : (
                      <span className={styles.evidenceTitle}>{item.title}</span>
                    )}
                    {item.source && <span className={styles.evidenceSource}> — {item.source}</span>}
                    {item.note && <p className={styles.evidenceNote}>{item.note}</p>}
                  </li>
                ))}
              </ul>
            </section>
          )}
          {articleVideo && (
            <ArticleVideoCard
              youtubeId={articleVideo.youtubeId}
              title={articleVideo.title || post.title}
              poster={post.image || undefined}
            />
          )}
          <SignatureMark tone="article" label="שלכם," className={styles.articleSignature} />
          <ShareButtons
            title={post.title}
            url={shareUrl}
            itemId={post.id}
            placement="article_bottom"
          />
          <GooglePreferredSource />
          <LeadMagnet />
          <p className={styles.disclaimer}>המאמר מספק מידע כללי ואינו מחליף ייעוץ מקצועי המותאם למצב האישי או המשפחתי.</p>
        </div>
        <aside className={styles.sidebar}>
          {'video' in post && post.video && (
            <div className={styles.videoCard}>
              <h3>🎬 הסבר קצר בנושא</h3>
              <div className={styles.videoWrapper}>
                <video
                  src={post.video as string}
                  controls
                  playsInline
                  preload="metadata"
                  className={styles.video}
                  poster={post.image || undefined}
                />
              </div>
            </div>
          )}
          <div className={styles.ctaCard}>
            <h3>צריכים עזרה עם הנושא הזה?</h3>
            <p>אני כאן כדי ללוות אתכם בתהליך אישי ומותאם לכם.</p>
            {relatedService && (
              <Link to={relatedService.url} className={styles.ctaButton}>{relatedService.label}</Link>
            )}
            <Link to={SITE_CONFIG.links.appointment} className={styles.ctaButton}>קביעת פגישת ייעוץ</Link>
          </div>
        </aside>
      </div>
      <div className={`container ${styles.finalCtaContainer}`}>
        <section className={styles.articleContactCta} aria-label="פנייה לשירה סהרוני">
          <h3>זה פוגש משהו שקורה אצלכם?</h3>
          <p>{ctaCopy}</p>
          <div className={styles.contactActions}>
            <Link to={SITE_CONFIG.links.appointment} className={styles.appointmentBtn}>
              <FiCalendar aria-hidden="true" />
              לקביעת פגישה עם שירה
            </Link>
            <a href={SITE_CONFIG.links.whatsapp} className={styles.whatsappBtn}>
              <FaWhatsapp aria-hidden="true" />
              לכתיבה לשירה בוואטסאפ
            </a>
          </div>
        </section>
      </div>
    </article>
  );
};

export default BlogPost;
