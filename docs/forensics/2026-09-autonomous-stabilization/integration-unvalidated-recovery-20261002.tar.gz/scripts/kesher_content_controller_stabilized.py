#!/usr/bin/env python3
"""Production Kesher V5 runtime with fail-closed article and media-quality preflights."""

from __future__ import annotations

import copy
import json
import os
import sys
import urllib.parse

if __package__:
    from . import article_claim_quality as quality
    from . import kesher_content_controller_v5 as v5
    from . import kesher_content_controller_v5_runtime as runtime
else:
    import article_claim_quality as quality
    import kesher_content_controller_v5 as v5
    import kesher_content_controller_v5_runtime as runtime


_ORIGINAL_PUBLIC_SITE_GET = v5.core.PublicSiteClient.get
_SOURCE_BINDING_EXHAUSTION_RECOVERY_MARKER = "source_binding_exhaustion_recovery_applied"
_REMOTION_REBUILD_EXHAUSTION_RECOVERY_MARKER = "remotion_rebuild_exhaustion_recovery_applied"


def _unicode_safe_public_site_get(self, url: str):
    """Percent-encode non-ASCII URL components before urllib builds the request."""
    parts = urllib.parse.urlsplit(url)
    safe_url = urllib.parse.urlunsplit((
        parts.scheme,
        parts.netloc,
        urllib.parse.quote(parts.path, safe="/%:@"),
        urllib.parse.quote(parts.query, safe="=&%:@/?+"),
        urllib.parse.quote(parts.fragment, safe="%:@/?+"),
    ))
    return _ORIGINAL_PUBLIC_SITE_GET(self, safe_url)


class StabilizedRuntimeV5Controller(runtime.RuntimeV5Controller):
    """Prevent advancement/completion unless article and canonical media evidence are durable."""


    def _selected_article(self, posts):
        """Prefer an explicit bounded media-recovery slug over today's article."""
        target_slug = os.environ.get("KESHER_TARGET_MEDIA_SLUG", "").strip()
        if target_slug:
            matches = [
                post for post in posts
                if isinstance(post, dict)
                and str(post.get("slug") or post.get("id") or "").strip() == target_slug
            ]
            if len(matches) != 1:
                raise v5.core.ControllerError(
                    f"TARGET_MEDIA_SOURCE_AMBIGUOUS: {target_slug} matched {len(matches)} articles"
                )
            return matches[0]

        todays = v5.core.today_articles(posts, self.now.date())
        return todays[0] if len(todays) == 1 else None

    def _article_source(self):
        posts = self.github.contents_json("src/data/posts.json", "main")
        if not isinstance(posts, list):
            raise v5.core.ControllerError("ARTICLE_SOURCE_INVALID")
        article = self._selected_article(posts)
        return v5.article_source_identity(article) if article is not None else None

    def _recover_stale_source_binding_exhaustion(self, state):
        """Reset one historical V5 attempt budget only when stale source binding is proven.

        Before the source-binding repair, the inherited provider-resume lookup could
        bind the current cycle to an unrelated FIFO NotebookLM item and consume the
        three-attempt budget. After the repair is deployed, that persisted exhaustion
        would otherwise remain terminal forever. Recover exactly once, and only when
        durable video state contains an unresolved item for the authoritative source
        while the controller's stored item/provider identifiers point elsewhere.
        """
        long_video = state.get("long_video") if isinstance(state.get("long_video"), dict) else {}
        last_error = state.get("last_error") if isinstance(state.get("last_error"), dict) else {}
        if (
            state.get("status") != "blocked"
            or long_video.get("status") != "exhausted"
            or str(last_error.get("code") or "") != "VIDEO_ATTEMPTS_EXHAUSTED"
            or long_video.get(_SOURCE_BINDING_EXHAUSTION_RECOVERY_MARKER)
        ):
            return state

        source = self._article_source()
        if source is None:
            return state
        snapshot = self.github.newest_video_state()
        exact = [
            item for item in v5._exact_items(snapshot, source)
            if item.get("uploaded") is not True
        ]
        if len(exact) != 1:
            return state

        exact_item = exact[0]
        exact_ids = {str(exact_item.get("id") or "").strip()}
        exact_provider_ids = {str(exact_item.get("task_id") or "").strip()}
        exact_artifact_ids = {str(exact_item.get("artifact_id") or "").strip()}
        exact_source_ids = {str(exact_item.get("source_id") or "").strip()}
        exact_ids.discard("")
        exact_provider_ids.discard("")
        exact_artifact_ids.discard("")
        exact_source_ids.discard("")

        bindings = (
            ("item_id", exact_ids),
            ("provider_id", exact_provider_ids),
            ("artifact_id", exact_artifact_ids),
            ("source_id", exact_source_ids),
        )
        stale_fields = [
            field for field, valid in bindings
            if str(long_video.get(field) or "").strip()
            and str(long_video.get(field) or "").strip() not in valid
        ]
        if not stale_fields:
            return state

        previous = {
            "attempt_count": long_video.get("attempt_count"),
            "item_id": long_video.get("item_id"),
            "provider_id": long_video.get("provider_id"),
            "artifact_id": long_video.get("artifact_id"),
            "source_id": long_video.get("source_id"),
            "watchdog": long_video.get("watchdog"),
        }
        long_video[_SOURCE_BINDING_EXHAUSTION_RECOVERY_MARKER] = True
        long_video["source_binding_recovery_previous"] = previous
        long_video["attempt_count"] = 0
        long_video["status"] = "pending"
        long_video["last_error"] = None
        long_video["next_retry_at"] = None
        long_video["run_id"] = None
        long_video["processed_run_id"] = None
        long_video["provider_id"] = None
        long_video["artifact_id"] = None
        long_video["source_id"] = None
        long_video["item_id"] = None
        long_video["last_dispatch_at"] = None
        long_video["last_run_conclusion"] = None
        long_video["resume_dispatches"] = 0
        long_video["failure_fingerprint"] = None
        long_video["same_failure_streak"] = 0
        long_video["failure_count_by_type"] = {}
        long_video.pop("watchdog", None)

        state["status"] = "article_live"
        state["last_error"] = None
        state.setdefault("history", []).append({
            "at": v5.core.utc_now(),
            "from": "blocked",
            "to": "article_live",
            "reason": "source_binding_exhaustion_recovery",
            "details": {
                "slug": source["slug"],
                "content_sha256": source["content_sha256"],
                "exact_item_id": exact_item.get("id"),
                "stale_fields": stale_fields,
                "attempt_budget_reset": True,
            },
        })
        state["history"] = state["history"][-100:]
        state["updated_at"] = v5.core.utc_now()
        return state

    def _recover_exact_rejected_exhaustion(self, state):
        """Give one fresh budget to an exact rejected Overview that needs Remotion repair.

        A rejected exact item is not a provider-generation failure. Re-dispatching the
        normal full operation only reselects the same rejected artifact and burns the
        controller budget. Recover once when the exact item lacks a verified full-screen
        signature so the next dispatch can use the dedicated Remotion rebuild operation.
        """
        long_video = state.get("long_video") if isinstance(state.get("long_video"), dict) else {}
        last_error = state.get("last_error") if isinstance(state.get("last_error"), dict) else {}
        if (
            state.get("status") != "blocked"
            or long_video.get("status") != "exhausted"
            or str(last_error.get("code") or "") != "VIDEO_ATTEMPTS_EXHAUSTED"
            or long_video.get(_REMOTION_REBUILD_EXHAUSTION_RECOVERY_MARKER)
        ):
            return state

        source = self._article_source()
        if source is None:
            return state
        snapshot = self.github.newest_video_state()
        exact_rejected = [
            item for item in v5._exact_items(snapshot, source)
            if item.get("uploaded") is not True
            and str(item.get("status") or "") == "rejected"
            and item.get("signature_fullscreen") is not True
        ]
        if len(exact_rejected) != 1:
            return state

        item = exact_rejected[0]
        previous = {
            "attempt_count": long_video.get("attempt_count"),
            "item_id": long_video.get("item_id"),
            "provider_id": long_video.get("provider_id"),
            "artifact_id": long_video.get("artifact_id"),
            "source_id": long_video.get("source_id"),
            "last_error": long_video.get("last_error"),
        }
        long_video[_REMOTION_REBUILD_EXHAUSTION_RECOVERY_MARKER] = True
        long_video["remotion_rebuild_recovery_previous"] = previous
        long_video["attempt_count"] = 0
        long_video["status"] = "pending"
        long_video["last_error"] = None
        long_video["next_retry_at"] = None
        long_video["run_id"] = None
        long_video["processed_run_id"] = None
        long_video["last_dispatch_at"] = None
        long_video["last_run_conclusion"] = None
        long_video["failure_fingerprint"] = None
        long_video["same_failure_streak"] = 0
        long_video["failure_count_by_type"] = {}
        long_video.pop("watchdog", None)
        long_video.update({
            "item_id": item.get("id"),
            "provider_id": item.get("task_id"),
            "artifact_id": item.get("artifact_id"),
            "source_id": item.get("source_id"),
        })

        state["status"] = "article_live"
        state["last_error"] = None
        state.setdefault("history", []).append({
            "at": v5.core.utc_now(),
            "from": "blocked",
            "to": "article_live",
            "reason": "exact_rejected_overview_remotion_recovery",
            "details": {
                "slug": source["slug"],
                "content_sha256": source["content_sha256"],
                "item_id": item.get("id"),
                "attempt_budget_reset": True,
            },
        })
        state["history"] = state["history"][-100:]
        state["updated_at"] = v5.core.utc_now()
        return state

    def state(self):
        state = super().state()
        state = self._recover_stale_source_binding_exhaustion(state)
        return self._recover_exact_rejected_exhaustion(state)

    def _quality_preflight(self, state):
        posts = self.github.contents_json("src/data/posts.json", "main")
        if not isinstance(posts, list):
            raise v5.core.ControllerError("ARTICLE_SOURCE_INVALID")
        article = self._selected_article(posts)
        if article is None:
            return None

        source = v5.article_source_identity(article)
        violations = quality.article_violations(article)
        state["article"].update({
            "quality_status": "failed" if violations else "passed",
            "quality_content_sha256": source["content_sha256"],
            "quality_checked_at": v5.core.utc_now(),
            "quality_violations": violations,
        })
        if not violations:
            return None

        message = " | ".join(violations[:3])
        v5.core.block(
            state,
            "article",
            quality.ERROR_CODE,
            f"article quality gate failed for {source['slug']}@{source['content_sha256'][:12]}: {message}",
        )
        self.github.save_controller_state(state)
        return v5.core.Action("blocked", "article content quality failed before deploy/media")

    def _dispatch_exact_rejected_rebuild(self, state):
        """Preempt legacy V5 rejection handling and rebuild the exact item with Remotion."""
        source = self._article_source()
        if source is None:
            return None
        snapshot = self.github.newest_video_state()
        exact_rejected = [
            item for item in v5._exact_items(snapshot, source)
            if item.get("uploaded") is not True
            and str(item.get("status") or "") == "rejected"
            and item.get("signature_fullscreen") is not True
        ]
        if len(exact_rejected) > 1:
            v5.core.block(
                state,
                "long_video",
                "DUPLICATE_REJECTED_LONG_VIDEO_ITEMS",
                f"{len(exact_rejected)} rejected exact Overview items exist for {source['slug']}",
            )
            self.github.save_controller_state(state)
            return state, v5.core.Action("blocked", "duplicate rejected long-video items")
        if not exact_rejected:
            return None

        item = exact_rejected[0]
        item_id = str(item.get("id") or "").strip()
        if not item_id:
            v5.core.block(state, "long_video", "REJECTED_LONG_VIDEO_ITEM_ID_MISSING", "rejected exact Overview has no item id")
            self.github.save_controller_state(state)
            return state, v5.core.Action("blocked", "rejected long-video item id missing")

        active = self.github.active_workflow_run(v5.LONG_VIDEO_WORKFLOW, production_only=True)
        if active:
            current = state["long_video"]
            current["run_id"] = active.get("id")
            current["status"] = "running"
            v5.core.transition(state, "long_video_running", "exact rejected Overview rebuild workflow already active", item_id=item_id)
            self.github.save_controller_state(state)
            return state, v5.core.Action("wait", "long-video rebuild workflow active")

        current = state["long_video"]
        count = int(current.get("attempt_count") or 0)
        if count >= v5.v3.MAX_STAGE_ATTEMPTS:
            return None

        rebuild_inputs = {
            "operation": "rebuild",
            "rebuild_item_id": item_id,
            "target_slug": source["slug"],
            "target_content_sha256": source["content_sha256"],
            "target_item_id": item_id,
        }
        v5.core.GitHubClient.dispatch(self.github, v5.LONG_VIDEO_WORKFLOW, rebuild_inputs)
        current["attempt_count"] = count + 1
        current["remotion_rebuild_dispatches"] = int(current.get("remotion_rebuild_dispatches") or 0) + 1
        current["last_dispatch_at"] = v5.core.utc_now()
        current["status"] = "running"
        current["next_retry_at"] = None
        current["item_id"] = item.get("id")
        current["source_id"] = item.get("source_id")
        current["artifact_id"] = item.get("artifact_id")
        current["provider_id"] = item.get("task_id")
        v5.core.transition(
            state,
            "long_video_running",
            "exact rejected Overview dispatched to Remotion rebuild",
            item_id=item_id,
        )
        self.github.save_controller_state(state)
        return state, v5.core.Action("dispatch_long_video", "rebuild exact rejected Overview", rebuild_inputs)

    def _dispatch_budgeted(self, state, stage, workflow, inputs):
        """Bind every long-video action to the authoritative source identity and recovery mode."""
        bound_inputs = dict(inputs or {})
        if stage != "video" or workflow != v5.LONG_VIDEO_WORKFLOW:
            return super()._dispatch_budgeted(state, stage, workflow, bound_inputs)

        source = self._article_source()
        if source is None:
            raise v5.core.ControllerError("LONG_VIDEO_SOURCE_IDENTITY_UNAVAILABLE")
        target_slug = str(bound_inputs.get("target_slug") or "").strip()
        if bound_inputs.get("operation") in {"full", "generate"}:
            if target_slug and target_slug != source["slug"]:
                raise v5.core.ControllerError("LONG_VIDEO_SOURCE_IDENTITY_MISMATCH")
            bound_inputs["target_slug"] = source["slug"]

        snapshot = self.github.newest_video_state()
        exact_rejected = [
            item for item in v5._exact_items(snapshot, source)
            if item.get("uploaded") is not True
            and str(item.get("status") or "") == "rejected"
            and item.get("signature_fullscreen") is not True
        ]
        if len(exact_rejected) > 1:
            raise v5.core.ControllerError("DUPLICATE_REJECTED_LONG_VIDEO_ITEMS")
        if exact_rejected:
            item = exact_rejected[0]
            rebuild_inputs = {
                "operation": "rebuild",
                "rebuild_item_id": str(item.get("id") or ""),
                "target_slug": source["slug"],
                "target_content_sha256": source["content_sha256"],
                "target_item_id": str(item.get("id") or ""),
            }
            if not rebuild_inputs["rebuild_item_id"]:
                raise v5.core.ControllerError("REJECTED_LONG_VIDEO_ITEM_ID_MISSING")
            v5.v3.V3Controller._dispatch_budgeted(self, state, stage, workflow, rebuild_inputs)
            current = state["video"]
            current["remotion_rebuild_dispatches"] = int(current.get("remotion_rebuild_dispatches") or 0) + 1
            current["item_id"] = item.get("id")
            current["source_id"] = item.get("source_id")
            current["artifact_id"] = item.get("artifact_id")
            current["provider_id"] = item.get("task_id")
            return

        exact_generating = [
            item for item in v5._exact_items(snapshot, source)
            if item.get("uploaded") is not True
            and str(item.get("status") or "") == "generating"
            and str(item.get("source_id") or "").strip()
            and str(item.get("task_id") or "").strip()
            and str(item.get("artifact_id") or "").strip()
            and str(item.get("task_id") or "").strip() == str(item.get("artifact_id") or "").strip()
        ]
        if len(exact_generating) > 1:
            raise v5.core.ControllerError("DUPLICATE_LONG_VIDEO_PROVIDER_TASKS")
        if exact_generating:
            item = exact_generating[0]
            v5.core.GitHubClient.dispatch(self.github, workflow, bound_inputs)
            current = state["video"]
            current["attempt_count"] = max(1, int(current.get("attempt_count") or 0))
            current["resume_dispatches"] = int(current.get("resume_dispatches") or 0) + 1
            current["last_dispatch_at"] = v5.core.utc_now()
            current["status"] = "running"
            current["next_retry_at"] = None
            current["item_id"] = item.get("id")
            current["source_id"] = item.get("source_id")
            current["artifact_id"] = item.get("artifact_id")
            current["provider_id"] = item.get("task_id")
            return

        # No exact provider task is currently generating. Use the bounded V3
        # dispatch budget rather than the legacy global FIFO provider-resume
        # lookup, which can bind a different article's provider identity.
        return v5.v3.V3Controller._dispatch_budgeted(self, state, stage, workflow, bound_inputs)

    def _tick_targeted_media_recovery(self, state):
        """Advance only the explicitly requested existing article media chain."""
        posts = self.github.contents_json("src/data/posts.json", "main")
        if not isinstance(posts, list):
            raise v5.core.ControllerError("ARTICLE_SOURCE_INVALID")
        article = self._selected_article(posts)
        if article is None:
            raise v5.core.ControllerError("TARGET_MEDIA_SOURCE_UNAVAILABLE")

        source = v5.article_source_identity(article)
        title = str(article.get("title") or "").strip()
        url = f"{v5.core.SITE_URL}/blog/{source['slug']}"
        status, body = self.site.get(url)
        if status != 200 or not v5.core.article_is_public(body, title):
            v5.core.block(
                state,
                "article",
                "TARGET_MEDIA_ARTICLE_NOT_PUBLIC",
                f"targeted media article is not publicly verified: {source['slug']}",
            )
            self.github.save_controller_state(state)
            return state, v5.core.Action("blocked", "targeted media article is not public")

        target = state.setdefault("targeted_media_recovery", {})
        previous_identity = (
            str(target.get("slug") or "").strip(),
            str(target.get("content_sha256") or "").strip(),
        )
        current_identity = (source["slug"], source["content_sha256"])
        if any(previous_identity) and previous_identity != current_identity:
            # A targeted-recovery switch starts a new source identity. Never
            # carry public URLs/provider IDs from the prior target into the
            # new target, because that can create a false A+B+C completion.
            state["long_video"] = copy.deepcopy(v5.v3._stage_template())
            state["short"] = copy.deepcopy(v5.v3._stage_template())
            deliverables = state.get("deliverables")
            if isinstance(deliverables, dict):
                for key in (
                    "overview_youtube_url",
                    "short_youtube_url",
                    "overview_edit_verified",
                    "short_portrait_verified",
                    "short_signature_verified",
                    "short_origin_verified",
                ):
                    if key.endswith("_verified"):
                        deliverables[key] = False
                    else:
                        deliverables[key] = None
            target.clear()
            state.setdefault("history", []).append({
                "at": v5.core.utc_now(),
                "from": previous_identity[0] or None,
                "to": source["slug"],
                "reason": "targeted_media_source_identity_reset",
                "details": {
                    "previous_slug": previous_identity[0] or None,
                    "previous_content_sha256": previous_identity[1] or None,
                    "content_sha256": source["content_sha256"],
                },
            })
            state["history"] = state["history"][-100:]

        target.update({
            "slug": source["slug"],
            "content_sha256": source["content_sha256"],
            "article_url": url,
            "article_verified": True,
            "updated_at": v5.core.utc_now(),
        })

        snapshot = self.github.newest_video_state()
        long_item = v5._newest(v5._verified_exact(snapshot, source))
        if long_item is None:
            long_item = self._verified_long_from_artifact_history(source)

        if long_item is None:
            # Fresh exact evidence wins over inherited controller fields. If no
            # exact Overview exists for this source, old public identifiers
            # must not survive merely because the target dictionary was already
            # switched on an earlier tick.
            stale_long_evidence = any(
                state["long_video"].get(key)
                for key in ("youtube_id", "youtube_url", "item_id", "provider_id", "artifact_id", "source_id")
            )
            if stale_long_evidence:
                preserved_run_id = state["long_video"].get("run_id")
                state["long_video"] = copy.deepcopy(v5.v3._stage_template())
                state["long_video"]["run_id"] = preserved_run_id

            newest_short_state = getattr(self.github, "newest_short_state", None)
            short_snapshot = newest_short_state() if callable(newest_short_state) else {"items": []}
            exact_short = v5._newest(v5._verified_exact(short_snapshot, source))
            if exact_short is not None:
                self._adopt_existing_short(state, source)
                target["short_status"] = "complete"
                target["short_youtube_url"] = state["short"].get("youtube_url")
            else:
                stale_short_evidence = any(
                    state["short"].get(key)
                    for key in ("youtube_id", "youtube_url", "item_id", "provider_id", "artifact_id", "source_id")
                )
                if stale_short_evidence:
                    state["short"] = copy.deepcopy(v5.v3._stage_template())
                target["short_status"] = state["short"].get("status") or "pending"
                target.pop("short_youtube_url", None)

            target["complete"] = False
            target.pop("completed_at", None)
            target.pop("long_youtube_url", None)
            target.pop("long_item_id", None)

            deliverables = state.get("deliverables")
            if isinstance(deliverables, dict):
                deliverables["overview_youtube_url"] = None
                deliverables["overview_edit_verified"] = False
                if exact_short is None:
                    deliverables["short_youtube_url"] = None
                    deliverables["short_portrait_verified"] = False
                    deliverables["short_signature_verified"] = False
                    deliverables["short_origin_verified"] = False

            active = self.github.active_workflow_run(v5.LONG_VIDEO_WORKFLOW, production_only=True)
            if active:
                state["long_video"]["run_id"] = active.get("id")
                state["long_video"]["status"] = "running"
                target["long_status"] = "running"
                self.github.save_controller_state(state)
                return state, v5.core.Action("wait", "targeted long-video workflow active")

            state["video"] = state["long_video"]
            try:
                self._dispatch_budgeted(
                    state,
                    "video",
                    v5.LONG_VIDEO_WORKFLOW,
                    {"operation": "full", "target_slug": source["slug"]},
                )
                state["long_video"] = state["video"]
            finally:
                state.pop("video", None)
            state["long_video"]["status"] = "running"
            target["long_status"] = "running"
            target["long_last_dispatch_at"] = v5.core.utc_now()
            self.github.save_controller_state(state)
            return state, v5.core.Action(
                "dispatch_long_video",
                "targeted media recovery dispatched exact Video Overview",
                {"operation": "full", "target_slug": source["slug"]},
            )

        state["long_video"].update({
            "item_id": long_item.get("id"),
            "status": "complete",
            "youtube_id": long_item.get("youtube_id"),
            "youtube_url": long_item.get("youtube_url"),
            "verified": True,
            "provider_id": long_item.get("task_id"),
            "artifact_id": long_item.get("artifact_id"),
            "source_id": long_item.get("source_id"),
        })
        target.update({
            "long_status": "complete",
            "long_youtube_url": long_item.get("youtube_url"),
            "long_item_id": long_item.get("id"),
        })

        action = self._tick_short(state, source, long_item)
        if action.kind == "complete":
            target["short_status"] = "complete"
            target["short_youtube_url"] = state["short"].get("youtube_url")
            target["complete"] = True
            target["completed_at"] = v5.core.utc_now()
        elif state["short"].get("status"):
            target["short_status"] = state["short"].get("status")
        self.github.save_controller_state(state)
        return state, action

    def _overview_evidence_preflight(self, state):
        """Copy exact public Overview edit evidence into durable controller state."""
        source = self._article_source()
        if source is None:
            return

        # Production is fail-closed: once an authoritative article exists, a
        # public URL alone is never sufficient to complete the Overview stage.
        state["long_video"]["overview_evidence_required"] = True

        snapshot = self.github.newest_video_state()
        item = v5._newest(v5._verified_exact(snapshot, source))
        if item is None:
            item = self._verified_long_from_artifact_history(source)
        if item is None:
            return

        media = item.get("media") or {}
        state["long_video"].update({
            "item_id": item.get("id"),
            "youtube_id": item.get("youtube_id"),
            "youtube_url": item.get("youtube_url"),
            "verified": True,
            "technical_verified": item.get("technical_verified") is True,
            "visual_pipeline": item.get("visual_pipeline"),
            "codec": media.get("codec"),
            "width": media.get("width"),
            "height": media.get("height"),
            "duration": media.get("duration"),
            "content_duration_seconds": item.get("content_duration_seconds"),
            "signature_duration_seconds": item.get("signature_duration_seconds"),
            "signature_fullscreen": item.get("signature_fullscreen"),
            "signature_asset_sha256": item.get("signature_asset_sha256"),
            "provider_id": item.get("task_id"),
            "artifact_id": item.get("artifact_id"),
            "source_id": item.get("source_id"),
        })

    def tick(self):
        state = self.state()
        blocker = self._quality_preflight(state)
        if blocker is not None:
            return state, blocker

        if os.environ.get("KESHER_TARGET_MEDIA_SLUG", "").strip():
            direct_rebuild = self._dispatch_exact_rejected_rebuild(state)
            if direct_rebuild is not None:
                return direct_rebuild
            return self._tick_targeted_media_recovery(state)

        self._overview_evidence_preflight(state)
        direct_rebuild = self._dispatch_exact_rejected_rebuild(state)
        if direct_rebuild is not None:
            return direct_rebuild

        self.github.save_controller_state(state)
        return super().tick()


def install_runtime() -> None:
    runtime.install_runtime()
    v5.core.PublicSiteClient.get = _unicode_safe_public_site_get
    v5.V5Controller = StabilizedRuntimeV5Controller


def main() -> int:
    from scripts.kesher_runtime.legacy_retirement import retired_entrypoint
    retired_entrypoint()
    install_runtime()
    return v5.main()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (v5.core.ControllerError, ValueError, KeyError, json.JSONDecodeError) as exc:
        print(f"KESHER_CONTROLLER_STABILIZED_BLOCKED {exc}", file=sys.stderr)
        raise SystemExit(1)