import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/Users/ninja/.codex/worktrees/stabilization-transplant-v6/Kesher'); out=Path('/Users/ninja/.codex/tmp/kesher-final-v9-20261004')
env=os.environ.copy();env['PATH']='/Users/ninja/.codex/tmp/kesher-final-v8-20261003/venv/bin:/Users/ninja/.nvm/versions/node/v24.21.0/bin:/Users/ninja/.codex/tmp/kesher-tools/actionlint-1.7.12:'+env['PATH'];env['PYTHONPATH']=str(root)
phase=sys.argv[1];commands=json.loads(sys.argv[2]);result={'phase':phase,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'gates':[]}
for name,cmd in commands:
 print('START '+name,flush=True);start=time.monotonic();log=out/(phase+'-'+name+'.log')
 with log.open('w') as stream:run=subprocess.run(['/bin/zsh','-c',cmd],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit_code':run.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};result['gates'].append(row);(out/(phase+'-validation.json')).write_text(json.dumps(result,indent=2)+'\n');print('RESULT '+json.dumps(row),flush=True)
 if run.returncode:break
result['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();result['all_passed']=len(result['gates'])==len(commands) and all(r['exit_code']==0 for r in result['gates']);(out/(phase+'-validation.json')).write_text(json.dumps(result,indent=2)+'\n')
sys.exit(0 if result['all_passed'] else 1)
