const {test,expect}=require("/Users/ninja/.codex/worktrees/stabilization-transplant-v6/Kesher/node_modules/@playwright/test");
const fs=require('fs');
const post=JSON.parse(fs.readFileSync("/Users/ninja/.codex/worktrees/stabilization-transplant-v6/Kesher/src/data/posts.json",'utf8')).find(p=>p.slug==='sleep-needs-10-year-old');
const article='/blog/'+post.id;
test.beforeEach(async({page})=>{
 await page.route('https://news.google.com/**',r=>r.fulfill({status:200,body:''}));
 await page.route('https://assets.calendly.com/**',r=>r.fulfill({status:200,body:''}));
});
test('rewritten sleep article retains exact main title body metadata and image',async({page})=>{
 const errors=[]; page.on('pageerror',e=>errors.push(e.message));
 await page.goto(article,{waitUntil:'domcontentloaded'});
 await expect(page.locator('h1')).toHaveText(post.title);
 await expect(page.locator('meta[name="description"]')).toHaveAttribute('content',post.excerpt);
 await expect(page.locator('link[rel="canonical"]')).toHaveAttribute('href','https://kesher.saharoni.com'+article);
 await expect(page.locator('[data-kesher-article-date]')).toHaveAttribute('data-kesher-article-date',post.date);
 await expect(page.locator('[data-kesher-article-hero]')).toHaveAttribute('src',post.image);
 await expect.poll(()=>page.locator('[data-kesher-article-hero]').evaluate(i=>i.complete&&i.naturalWidth>=640&&i.naturalHeight>=360)).toBe(true);
 const first=await page.evaluate(html=>new DOMParser().parseFromString(html,'text/html').querySelector('p').textContent,post.content);
 await expect(page.locator('[data-kesher-article-body] > p').first()).toHaveText(first);
 const expectedHeaders=await page.evaluate(html=>Array.from(new DOMParser().parseFromString(html,'text/html').querySelectorAll('h3')).map(n=>n.textContent),post.content);
 await expect(page.locator('[data-kesher-article-body] h3')).toHaveText(expectedHeaders);
 await expect(page.getByRole('region',{name:'תשובה תמציתית'})).toContainText(post.directAnswer||post.excerpt);
 const schemas=await page.locator('script[type="application/ld+json"]').evaluateAll(nodes=>nodes.flatMap(n=>{const j=JSON.parse(n.textContent);return j['@graph']||[j]}));
 const schema=schemas.find(n=>n['@type']==='Article');
 expect(schema.headline).toBe(post.title); expect(schema.description).toBe(post.excerpt); expect(schema.dateModified).toBe(post.updatedAt||post.date);
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=document.documentElement.clientWidth)).toBe(true);
 expect(errors).toEqual([]);
});
test('blog index exposes current rewritten sleep title and navigation',async({page})=>{
 await page.goto('/blog',{waitUntil:'domcontentloaded'});
 await expect(page.locator('h1')).toHaveCount(1);
 await page.getByRole('textbox',{name:'חיפוש מאמרים'}).fill(post.title);
 const link=page.locator('h2').getByRole('link',{name:post.title,exact:true});
 await expect(link).toHaveCount(1); await expect(link).toContainText(post.title);
 await link.click(); await expect(page).toHaveURL(new RegExp(article+'$'));
 await expect(page.locator('h1')).toHaveText(post.title);
});
