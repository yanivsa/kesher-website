import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/Users/ninja/.codex/worktrees/stabilization-transplant-v6/Kesher'); out=Path('/Users/ninja/.codex/tmp/kesher-final-v9-20261004'); old=Path('/Users/ninja/.codex/tmp/kesher-final-v8-20261003')
env=os.environ.copy(); env['PATH']=str(old/'venv/bin')+':/Users/ninja/.nvm/versions/node/v24.21.0/bin:/Users/ninja/.codex/tmp/kesher-tools/actionlint-1.7.12:'+env['PATH']; env['PYTHONPATH']=str(root); env['PYTEST_ADDOPTS']='--junitxml='+str(out/'incremental-pytest.xml')
commands=[
('diff-check','git diff --check && git diff --check --cached'),
('compile','python3 -m py_compile scripts/kesher_runtime/*.py scripts/*.py tests/*.py .github/scripts/article-image-worker.py .github/scripts/article-image-worker-v3.py .github/scripts/article-image-worker-v4.py'),
('actionlint','actionlint -shellcheck= -pyflakes='),
('affected-pytest','pytest tests/test_article_image_worker.py tests/test_article_image_contract.py tests/test_article_image_fallback_exhaustion.py tests/test_article_image_validator_policy.py tests/test_kesher_article_image_worker.py tests/test_kesher_article_contract.py tests/test_kesher_article_public.py tests/test_kesher_provider_recovery.py tests/test_kesher_authority_digest.py tests/test_kesher_authority_topology.py tests/test_kesher_historical_evidence.py tests/test_kesher_worker_entry.py tests/test_kesher_worker_commands.py tests/test_kesher_state_write_safety.py tests/test_v5_backlog_media_recovery.py tests/test_v5_shared_video_controller.py'),
('content','npm run test:content'),
('website','npm test'),
('build-dist','npm run build && npm run verify:dist'),
('lint','npm run lint'),
('targeted-browser','npm run test:e2e -- --config '+str(out/'targeted-browser.config.cjs')),
]
result={'worktree':str(root),'current_main_sha':'7ae5b097e9be2dbe8e6287b1be9dfa2cdc9f6ac7','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'gates':[]}
for label,command in commands:
 print('START '+label,flush=True); started=time.monotonic(); log=out/('incremental-'+label+'.log')
 with log.open('w') as stream: run=subprocess.run(['/bin/zsh','-c',command],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 row={'name':label,'command':command,'exit_code':run.returncode,'seconds':round(time.monotonic()-started,3),'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}; result['gates'].append(row); (out/'incremental-validation.json').write_text(json.dumps(result,indent=2)+'\n'); print('RESULT '+json.dumps(row),flush=True)
result['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat(); result['all_passed']=all(r['exit_code']==0 for r in result['gates']); (out/'incremental-validation.json').write_text(json.dumps(result,indent=2)+'\n'); print('ALL_PASSED='+str(result['all_passed']).lower(),flush=True)
