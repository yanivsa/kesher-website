import ast,collections,hashlib,json,subprocess
from pathlib import Path
from scripts.kesher_runtime.authority_topology import policy,inventory,code_manifest
from scripts.kesher_runtime.identity import digest
root=Path('/Users/ninja/.codex/worktrees/stabilization-transplant-v6/Kesher');out=Path('/Users/ninja/.codex/tmp/kesher-final-v9-20261004');old='25dedfd87623ab8e23b375cfc1edfcbba19f14b7';main='7ae5b097e9be2dbe8e6287b1be9dfa2cdc9f6ac7';v7='1b3bf50ced84e34ddd4452a12a72233e1d917a81'
def raw(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=root)
def sha(data):return hashlib.sha256(data).hexdigest()
def put(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
exact=['src/data/posts.json','public/llms-full.txt','.github/kesher-media-recovery-request.json','scripts/generate-llms-full.cjs']
mainproof=[]
for p in exact:
 b=(root/p).read_bytes();assert b==raw(main,p),p;mainproof.append({'path':p,'sha256':sha(b),'exact_main_bytes':True})
image='.github/scripts/article-image-worker.py';new=ast.parse((root/image).read_bytes());before=ast.parse(raw(old,image));remote=ast.parse(raw(main,image));dump=lambda n:ast.dump(n,include_attributes=False)
helper=lambda module:next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='github_content')
assert dump(helper(new))==dump(helper(remote))
assert [dump(n) for n in new.body if n is not helper(new)]==[dump(n) for n in before.body if n is not helper(before)]
rules=policy(root);assert (root/'scripts/kesher_runtime/authority_policy.json').read_bytes()==raw(old,'scripts/kesher_runtime/authority_policy.json')
rows=inventory(root,rules);assert len(rows)==len(rules['workflows'])==72
manifest=code_manifest(root)
new_paths=['scripts/prerender.cjs','src/main.tsx','src/lib/hydration.ts','tests/hydration.test.ts','tests/e2e/article-hydration.spec.ts',image,'scripts/generate-llms-full.cjs','tests/test_article_image_worker.py']
assert all(p in manifest for p in new_paths)
assert not any(p in e['review']['call_chain'] for p in new_paths for e in rules['workflows'].values())
base='docs/forensics/2026-09-autonomous-stabilization/'
protected=['closed-media-evidence-floor-20260930.json','legacy-media-adjudication-20260928.json','legacy-media-evidence-report-20260928.md','migration-legacy-evidence-replay-20260928.json','handover-hardening-replay-20260930.json']
floors=[]
for p in protected:
 b=(root/base/p).read_bytes();assert b==raw(v7,base+p);floors.append({'path':base+p,'sha256':sha(b),'v7_byte_identical':True})
workers=[r for r in rows if r['role']=='worker']
for w in workers:assert (root/w['path']).read_bytes()==raw(old,w['path'])
put('final-authority-main-floor-proof.json',{'main_sha':main,'interrupted_candidate_sha':old,'main_exact_byte_paths':mainproof,'image_worker_semantics':'github_content AST exact main; every other module AST node exact interrupted reviewed candidate','workflow_count':72,'policy_count':72,'roles':dict(collections.Counter(r['role'] for r in rows)),'stale_definitions':0,'stale_call_chains':0,'unknown_definitions':0,'dispatch_bindings':'PASS through inventory/check_definitions/_dispatch_review','policy_digest':digest(rules),'policy_raw_sha256':sha((root/'scripts/kesher_runtime/authority_policy.json').read_bytes()),'hash_updates':[],'capability_role_resource_credentials_dispatch_changes':0,'changed_unpinned_execution_paths':new_paths,'whole_code_manifest_binds_every_changed_execution_path':True,'workers':workers,'workers_byte_identical_interrupted_candidate':True,'historical_byte_proof':floors,'production_state_written':False,'production_activated':False,'public_completion_inferred':False})
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',old],cwd=root,text=True).splitlines()
changed=subprocess.check_output(['git','diff','--name-only',old],cwd=root,text=True).splitlines()
allowed=set(exact+['public/rss.xml','public/sitemap.xml','src/data/postSummaries.json']+new_paths)
assert set(changed)<=allowed,set(changed)-allowed
selected=[p for p in paths if p.startswith(('scripts/kesher_runtime/','src/remotion/','remotion-kesher/','.github/workflows/','tests/test_kesher_','tests/test_video_','tests/test_short_','tests/test_media_')) or p in ['scripts/kesher_daily_pipeline.py','scripts/kesher_short_pipeline_v4.py','tests/real_media_render.py','package.json','package-lock.json','requirements.txt','playwright.config.ts']]
assert not set(selected)&set(changed)
retained={p:sha((root/p).read_bytes()) for p in selected if (root/p).is_file() and not (root/p).is_symlink()}
put('final-prior-validation-input-preservation.json',{'prior_checkpoint_sha':old,'current_main_sha':main,'changed_tracked_paths':changed,'added_regression':'tests/e2e/article-hydration.spec.ts','unrelated_full_python_controller_video_and_synthetic_inputs_sha256':retained,'unchanged_selected_execution_input_count':len(retained),'affected_python_paths':['.github/scripts/article-image-worker.py','tests/test_article_image_worker.py'],'affected_python_validated_by_201_test_subset':True,'website_and_browser_execution_inputs_changed':True,'full_website_and_full_browser_rerun_required':True,'prior_browser138_not_used_as_current_browser_proof':True,'full_media_render_inputs_unchanged':True,'reason_no_full_controller_video_synthetic_rerun':'Canonical runtime, workflows, media renderer/pipelines and their tests unchanged; legacy image GET helper exact main is covered by affected article/image/provider gates.'})
print('PASS exact-main4; 72/72 authority; policy unchanged; all changed execution paths bound; floor5 unchanged; prior unaffected execution inputs',len(retained),'changed tracked paths',len(changed))
